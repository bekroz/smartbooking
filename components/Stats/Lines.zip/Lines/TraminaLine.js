import React from 'react';
import { View, StyleSheet } from 'react-native';
import { COLORS } from '../../../constants/theme';

const TraminaLine = () => {
  return (
    <View
      style={[
        styles.lineStyle,
        {
          backgroundColor: COLORS.pinkCircle,

          width: lineWidth,
        },
      ]}
    />
  );
};

export default TraminaLine;

const styles = StyleSheet({
  lineStyle: {
    maxWidth: 222,
    height: 10,
    borderRadius: 50,
    marginRight: 6,
  },
});
