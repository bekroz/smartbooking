import React from 'react';
import { View, StyleSheet } from 'react-native';
import { COLORS } from '../../../constants/theme';

const SitesLine = () => {
  return (
    <View
      style={[
        styles.lineStyle,
        {
          backgroundColor: COLORS.yellow,

          width: lineWidth,
        },
      ]}
    />
  );
};

export default SitesLine;

const styles = StyleSheet({
  lineStyle: {
    maxWidth: 222,
    height: 10,
    borderRadius: 50,
    marginRight: 6,
  },
});
