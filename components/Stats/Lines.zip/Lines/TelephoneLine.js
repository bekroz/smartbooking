import React from 'react';
import { View, StyleSheet } from 'react-native';
import { COLORS } from '../../../constants/theme';
const TelephoneLine = () => {
  return (
    <View
      style={[
        styles.lineStyle,
        {
          backgroundColor: COLORS.orange,

          width: lineWidth,
        },
      ]}
    />
  );
};

export default TelephoneLine;

const styles = StyleSheet({
  lineStyle: {
    maxWidth: 222,
    height: 10,
    borderRadius: 50,
    marginRight: 6,
  },
});
