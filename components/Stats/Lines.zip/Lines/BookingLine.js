import React from 'react';
import { View, StyleSheet } from 'react-native';
import { COLORS } from '../../../constants/theme';

const BookingLine = () => {
  return (
    <View
      style={[
        styles.lineStyle,
        {
          backgroundColor: COLORS.greenCircle,

          width: lineWidth,
        },
      ]}
    />
  );
};

export default BookingLine;

const styles = StyleSheet({
  lineStyle: {
    maxWidth: 222,
    height: 10,
    borderRadius: 50,
    marginRight: 6,
  },
});
