import React from 'react';
import { View, StyleSheet } from 'react-native';
import { COLORS } from '../../../constants/theme';

const DoloresLine = () => {
  return (
    <View
      style={[
        styles.lineStyle,
        {
          backgroundColor: COLORS.coral,

          width: lineWidth,
        },
      ]}
    />
  );
};

export default DoloresLine;

const styles = StyleSheet({
  lineStyle: {
    maxWidth: 222,
    height: 10,
    borderRadius: 50,
    marginRight: 6,
  },
});
