import React, { useEffect, useCallback, useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import dayjs from 'dayjs';
import { Card } from 'react-native-elements/dist/card/Card';
// Theme
import { COLORS, POSITIONING, SIZES } from '../../../../constants';
// Components
import {
  SpaceForScroll,
  CalendarModal,
  DotView,
  CollapseButton,
  WaterMarkHider,
  FadeInView,
  BarChart,
  RevenueDonut,
} from '../../../../components';
// Middleware
import { getChannelsDataMiddleware } from '../../../../redux/middlewares';
import { connect } from 'react-redux';
import { dottedTruncator, numberWithSpaces } from '../../../../helpers';
import Animated from 'react-native-reanimated';

const ChannelsDataShow = ({
  navigation,
  loading,
  channelsData,
  totalRevenue,
  totalSoldNights,
  totalAverageSum,
  chosenStartDate,
  chosenEndDate,
  error,
}) => {
  const [calendarModalVisible, setCalendarModalVisible] = useState(false);
  const [increasedBarCardSize, setIncreasedBarCardSize] = useState(false);

  const openCalendarModal = () => {
    setCalendarModalVisible(true);
  };
  const closeCalendarModal = () => {
    setCalendarModalVisible(false);
  };

  const onPullToRefresh = useCallback(() => {
    getChannelsDataMiddleware();
  }, []);

  useEffect(() => {
    getChannelsDataMiddleware();
  }, []);

  let refreshing = false;

  const monthStart = dayjs(chosenStartDate).locale('ru').format('D MMM');
  const monthEnd = dayjs(chosenEndDate).locale('ru').format('D MMM');
  function toggleBarCardSize() {
    setIncreasedBarCardSize(!increasedBarCardSize);
  }

  const barCardHeightAnimatedValue = useRef(new Animated.Value(315)).current;

  return (
    <ScrollView
      contentContainerStyle={{
        paddingBottom: 200,
      }}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onPullToRefresh}
          tintColor={COLORS.white}
        />
      }>
      <View style={styles.monthRangeButtonContainer}>
        <TouchableOpacity
          style={styles.calendarBtn}
          onPress={openCalendarModal}>
          <Text style={styles.calendarBtnText}>
            {monthStart} - {monthEnd}
          </Text>
        </TouchableOpacity>
      </View>

      {/* FIRST Card */}

      <Card containerStyle={[styles.card]} title="Доходи">
        <View style={styles.revenueCardTitlesContainer}>
          <View>
            <Text style={styles.revenueTitle}>Доход</Text>
            <Text style={styles.revenueDescription}>Revenue</Text>
          </View>
          <Text style={styles.totalAverageSumText}>
            Всего {totalAverageSum} UZS
          </Text>
        </View>
        <View style={styles.revenueContentContainer}>
          {/* Donut */}
          <RevenueDonut data={channelsData} />
          {/* Dots */}
          <View style={styles.revenueSourceNamesContainer}>
            {channelsData.map(({ source_name }, index) => (
              <View key={index}>
                <DotView sourceName={dottedTruncator(source_name, 15)} />
              </View>
            ))}
          </View>
        </View>
        <WaterMarkHider />
      </Card>

      {/* SECOND Card */}
      <Card
        containerStyle={{
          backgroundColor: COLORS.grayPlaceholder,
          borderColor: COLORS.grayPlaceholder,
          borderRadius: 6,
          width: SIZES.width - 30,
          overflow: 'hidden',
          height: barCardHeightAnimatedValue,
          backgroundColor: 'red',
        }}
        title="Продажи">
        <FadeInView>
          <View style={styles.averageStaysTitleContainer}>
            <View style={{ width: 110, marginRight: 15 }}>
              <Text style={styles.averageStaysPriceText}>
                Средняя цена номера
              </Text>
            </View>
            <View style={styles.totalAverageSumContainer}>
              <Text style={styles.totalAverageSumText}>
                Всего {totalRevenue}
              </Text>
            </View>
            <Text style={styles.totalAverageSumText}> UZS</Text>
          </View>
          <View style={styles.barChartContainer}>
            {/* <BarChart channelsData={channelsData} /> */}

            <Text>Не реализовано</Text>
          </View>
        </FadeInView>
        <CollapseButton
          onPress={() => {
            if (increasedBarCardSize) {
              Animated.timing(barCardHeightAnimatedValue, {
                toValue: 215,
                duration: 300,
                useNativeDriver: false,
              }).start();
            } else {
              Animated.timing(barCardHeightAnimatedValue, {
                toValue: 400,
                duration: 300,
                useNativeDriver: false,
              }).start();
            }
            toggleBarCardSize();
          }}
        />
      </Card>
      <CalendarModal
        isVisible={calendarModalVisible}
        open={openCalendarModal}
        close={closeCalendarModal}
        startDate={chosenStartDate}
        endDate={chosenEndDate}
        refreshData={onPullToRefresh}
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  calendarBtn: {
    borderRadius: 5,
    borderWidth: 0.167,
    ...POSITIONING.center,
    backgroundColor: '#353c46',
    borderColor: COLORS.blue,
    width: SIZES.width - 30,
    height: 35,
  },
  calendarBtnText: {
    fontWeight: SIZES.fontWeight1,
    textAlign: 'center',
    color: COLORS.white,
    fontSize: 15,
  },
  monthRangeButtonContainer: {
    flexDirection: 'row',
    marginTop: 5,
    paddingBottom: 0,
    paddingTop: 5,
    ...POSITIONING.center,
  },
  card: {
    backgroundColor: COLORS.grayPlaceholder,
    borderColor: COLORS.grayPlaceholder,
    borderRadius: 6,
    height: 210,
    width: SIZES.width - 30,
    overflow: 'hidden',
  },
  revenueCardTitlesContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
    zIndex: 1,
  },
  revenueTitle: {
    fontWeight: SIZES.fontWeight1,
    fontSize: 16,
    color: COLORS.white,
  },
  revenueDescription: {
    fontWeight: SIZES.fontWeight1,
    fontSize: 10,
    color: COLORS.grayText,
  },
  revenueContentContainer: {
    flexDirection: 'row',
    height: '100%',
    // backgroundColor: 'yellow',
  },
  revenueSourceNamesContainer: {
    flex: 1,
    top: -10,
    right: -25,
    // backgroundColor: 'red',
  },
  averageStaysTitleContainer: {
    flexDirection: 'row',
    marginBottom: 15,
    zIndex: 1,
  },
  averageStaysPriceText: {
    fontWeight: SIZES.fontWeight1,
    fontSize: SIZES.body5,
    color: COLORS.white,
  },
  chosenCardStyle: {
    borderColor: COLORS.blue,
  },
  priceText: {
    fontSize: SIZES.body5,
    fontWeight: SIZES.fontWeight2,
  },
  equalMargin: {
    marginTop: 10,
  },
  guestName: {
    color: COLORS.softBlue,
    fontSize: 16,
    fontWeight: SIZES.fontWeight3,
  },
  dotBlock: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  dotStyle: {
    width: 10,
    height: 10,
    borderRadius: 50,
    marginRight: 6,
  },
  lineStyle: {
    maxWidth: 222,
    height: 10,
    borderRadius: 50,
    marginRight: 6,
  },

  thirdCardDotMargin: {
    marginBottom: 5,
  },
  donutBlock: {
    width: 140,
    marginRight: 50,
    marginTop: 5,
    height: 120,
    ...POSITIONING.center,
  },
  totalAverageSumContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  totalAverageSumText: {
    color: COLORS.grayText,
  },
  barChartContainer: {
    backgroundColor: 'yellow',
    width: '70%',
    overflow: 'hidden',
  },
});

function mapStateToProps({
  channelsReducer,
  annualReducer,
  hotelReducer,
  dateReducer,
}) {
  const {
    loading,
    channelsData,
    totalRevenue,
    totalSoldNights,
    totalAverageSum,
    error,
  } = channelsReducer;
  const { annualData } = annualReducer;
  const { hotelID } = hotelReducer;
  const { chosenStartDate, chosenEndDate } = dateReducer;
  return {
    loading,
    chosenStartDate,
    chosenEndDate,
    channelsData,
    totalRevenue,
    totalSoldNights,
    totalAverageSum,
    error,
    annualData,
    hotelID,
  };
}

export default connect(mapStateToProps)(ChannelsDataShow);
