import React, { useEffect, useCallback, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import dayjs from 'dayjs';
import { Card } from 'react-native-elements/dist/card/Card';
// Theme
import { COLORS, POSITIONING, SIZES } from '../../../../constants';
// Components
import {
  SpaceForScroll,
  CalendarModal,
  DotView,
  CollapseButton,
  WaterMarkHider,
  FadeInView,
  BarChart,
} from '../../..';

import RevenueDonut from '../RevenueDonut';
// Middleware
import { getChannelsDataMiddleware } from '../../../../redux/middlewares';
import { connect } from 'react-redux';
import { dottedTruncator, numberWithSpaces } from '../../../../helpers';

const ChannelsDataShow = ({
  navigation,
  loading,
  channelsData,
  totalRevenue,
  totalSoldNights,
  totalAverageSum,
  chosenStartDate,
  chosenEndDate,
  error,
}) => {
  const [calendarModalVisible, setCalendarModalVisible] = useState(false);

  const openCalendarModal = () => {
    setCalendarModalVisible(true);
  };
  const closeCalendarModal = () => {
    setCalendarModalVisible(false);
  };

  const onPullToRefresh = useCallback(() => {
    getChannelsDataMiddleware();
  }, []);

  useEffect(() => {
    getChannelsDataMiddleware();
  }, []);

  let refreshing = false;

  const monthStart = dayjs(chosenStartDate).locale('ru').format('D MMM');
  const monthEnd = dayjs(chosenEndDate).locale('ru').format('D MMM');

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={onPullToRefresh}
          tintColor={COLORS.white}
        />
      }>
      <View style={styles.monthRangeButtonContainer}>
        <TouchableOpacity
          style={[
            styles.topBarBtn,
            {
              backgroundColor: '#292F3A',
              borderColor: '#5F85DB',
              width: SIZES.width - 30,
              height: 35,
            },
          ]}
          onPress={openCalendarModal}>
          <Text style={[styles.topBarText, { fontSize: 15 }]}>
            {monthStart} - {monthEnd}
          </Text>
        </TouchableOpacity>
      </View>

      {/* FIRST Card */}
      {!loading ? (
        <Card containerStyle={styles.card} title="Revenue">
          <FadeInView>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginBottom: 15,
                zIndex: 1,
              }}>
              <View>
                <Text
                  style={{
                    fontWeight: SIZES.fontWeight1,
                    fontSize: 16,
                    color: COLORS.white,
                  }}>
                  Доход
                </Text>
                <Text
                  style={{
                    fontWeight: SIZES.fontWeight1,
                    fontSize: 10,
                    color: COLORS.grayText,
                  }}>
                  Revenue
                </Text>
              </View>
              <Text style={styles.totalAverageSumText}>
                Всего {totalAverageSum} UZS
              </Text>
            </View>

            <View
              style={{
                flexDirection: 'row',
                // backgroundColor: 'yellow',
                // height: 100,
              }}>
              <RevenueDonut channelsData={channelsData} />
              {/* Color and Title */}
              <View style={{ flex: 1, top: -10, right: -25 }}>
                {/* Dots */}
                {channelsData.map(({ source_name }, index) => (
                  <View key={index}>
                    <DotView sourceName={dottedTruncator(source_name, 15)} />
                  </View>
                ))}
              </View>
            </View>
            <WaterMarkHider />
          </FadeInView>
        </Card>
      ) : null}
      {/* Second Card */}
      <Card containerStyle={styles.card} title="Revenue">
        {/* Card Context View */}
        {!loading ? null : (
          <ActivityIndicator
            animating={true}
            color={COLORS.white}
            marginTop={70}
          />
        )}
        {/* <View
          style={{
            position: 'absolute',
            backgroundColor: 'yellow',
          }}>
          <CollapseButton />
        </View> */}
      </Card>
      {/* Third Card */}
      <Card containerStyle={[styles.card, { height: 'auto' }]} title="Revenue">
        {/* Card Content */}
        {!loading ? (
          <FadeInView>
            <View
              style={{
                flexDirection: 'row',
                marginBottom: 15,
                zIndex: 1,
              }}>
              <View style={{ width: 110, marginRight: 15 }}>
                <Text
                  style={{
                    fontWeight: SIZES.fontWeight1,
                    fontSize: 16,
                    color: COLORS.white,
                  }}>
                  Средняя цена номера
                </Text>
              </View>
              <View
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  justifyContent: 'flex-end',
                }}>
                <Text style={styles.totalAverageSumText}>
                  Всего {totalRevenue}
                </Text>
              </View>
              <Text style={styles.totalAverageSumText}> UZS</Text>
            </View>
            <View
              style={{
                // flex: 1,
                // alignSelf: 'center',
                // backgroundColor: 'red',
                width: '100%',
                // height: '100%',
                height: 'auto',
                // overflow: 'hidden',
              }}>
              <BarChart channelsData={channelsData} />
            </View>
          </FadeInView>
        ) : (
          <ActivityIndicator
            animating={true}
            color={COLORS.white}
            marginTop={110}
          />
        )}
      </Card>
      <SpaceForScroll />
      <CalendarModal
        isVisible={calendarModalVisible}
        open={openCalendarModal}
        close={closeCalendarModal}
        startDate={chosenStartDate}
        endDate={chosenEndDate}
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  topBarBtn: {
    backgroundColor: '#2E3641',
    borderRadius: 5,
    borderWidth: 0.167,
    borderColor: '#000000',
    height: 30,
    width: 114,
    ...POSITIONING.center,
  },
  topBarText: {
    fontWeight: SIZES.fontWeight1,
    fontSize: 14,
    textAlign: 'center',
    color: COLORS.white,
  },
  monthRangeButtonContainer: {
    flexDirection: 'row',
    marginTop: 5,
    paddingBottom: 0,
    paddingTop: 5,
    ...POSITIONING.center,
  },
  card: {
    backgroundColor: COLORS.grayPlaceholder,
    borderColor: COLORS.grayPlaceholder,
    borderRadius: 6,
    height: 210,
    width: SIZES.width - 30,
    overflow: 'hidden',
  },
  chosenCardStyle: {
    borderColor: COLORS.blue,
  },
  priceText: {
    fontSize: SIZES.body5,
    fontWeight: SIZES.fontWeight2,
  },
  equalMargin: {
    marginTop: 10,
  },
  guestName: {
    color: COLORS.softBlue,
    fontSize: 16,
    fontWeight: SIZES.fontWeight3,
  },
  dotBlock: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  dotStyle: {
    width: 10,
    height: 10,
    borderRadius: 50,
    marginRight: 6,
  },
  lineStyle: {
    maxWidth: 222,
    height: 10,
    borderRadius: 50,
    marginRight: 6,
  },

  thirdCardDotMargin: {
    marginBottom: 5,
  },
  donutBlock: {
    width: 140,
    marginRight: 50,
    marginTop: 5,
    height: 120,
    ...POSITIONING.center,
  },
  totalAverageSumText: {
    color: COLORS.grayText,
  },
});

function mapStateToProps({
  channelsReducer,
  annualReducer,
  hotelReducer,
  dateReducer,
}) {
  const {
    loading,
    channelsData,
    totalRevenue,
    totalSoldNights,
    totalAverageSum,
    error,
  } = channelsReducer;
  const { annualData } = annualReducer;
  const { hotelID } = hotelReducer;
  const { chosenStartDate, chosenEndDate } = dateReducer;
  return {
    loading,
    chosenStartDate,
    chosenEndDate,
    channelsData,
    totalRevenue,
    totalSoldNights,
    totalAverageSum,
    error,
    annualData,
    hotelID,
  };
}

export default connect(mapStateToProps)(ChannelsDataShow);

// <View
// style={{
//   marginBottom: 5,
// }}>
// {channelsData?.map((channel, index) => (
//   <>
//     <View style={styles.dotBlock} key={index}>
//       {channel.source_name === 'От стойки' && (
//         <LineView lineWidth={100} />
//       )}

//       <Text style={{ color: COLORS.white }}>
//         {numberWithSpaces(channel.average_revenue)}{' '}
//         {channel.source_name}
//       </Text>
//       {/* <BookingLine  */}
//     </View>

//   </>
// ))}
// </View>

// <FadeInView>
//   <View
//     style={{
//       flexDirection: 'row',
//       justifyContent: 'space-between',
//       marginBottom: 15,
//       zIndex: 1,
//     }}>
//     <View>
//       <Text
//         style={{
//           fontWeight: SIZES.fontWeight1,
//           fontSize: 16,
//           color: COLORS.white,
//         }}>
//         К-ство проданных ночей
//       </Text>
//       <Text
//         style={{
//           fontWeight: SIZES.fontWeight1,
//           fontSize: 10,
//           color: COLORS.grayText,
//         }}>
//         Room Nights
//       </Text>
//     </View>
//     <Text style={{ color: COLORS.grayText }}>
//       {totalSoldNights} ночей
//     </Text>
//   </View>
//   <View style={{ flexDirection: 'row' }}>
//     {/* LEFT Donut View */}

//     {/* <Donut /> */}
//     <RevenueDonut channelsData={channelsData} />
//     {/* <FusionDonut /> */}
//     {/* Color and Title */}
//     <View style={{ flex: 1, top: -15 }}>
//       {/* Dots */}
//       {channelsData.map((channel, index) => (
//         <View>
//           <DotView key={index} sourceName={channel?.source_name} />
//         </View>
//       ))}
//     </View>
//   </View>

//   <WaterMarkHider />
// </FadeInView>
